

//// firls 核心函数，阶数N，频率F，幅度A，加权W
//af::array firls(int N, const std::vector<float>& F, const std::vector<float>& A, const std::vector<float>& W = std::vector<float>()) {
//    // 校验输入
//    if (F.size() != A.size()) {
//        throw std::runtime_error("频率向量和幅度向量大小不一致");
//    }
//    if (!W.empty() && W.size() != (F.size() / 2)) {
//        throw std::runtime_error("加权向量大小应为频率段数量");
//    }
//    if (F.front() != 0.0f || F.back() != 1.0f) {
//        throw std::runtime_error("频率向量必须从0开始，到1结束");
//    }
//    if (N <= 0) {
//        throw std::runtime_error("滤波器阶数必须正数");
//    }
//
//    int M = N / 2; // 对称滤波器长度一半
//
//    int nBands = (F.size() - 1) / 2; // 频率段数
//
//    // 默认权重为1
//    std::vector<float> weights = W;
//    if (weights.empty()) {
//        weights = std::vector<float>(nBands, 1.0f);
//    }
//
//    // 构造矩阵和向量
//    af::array Faf(F.size(), 1, &F[0]);
//    af::array Aaf(A.size(), 1, &A[0]);
//    af::array Waf(weights.size(), 1, &weights[0]);
//
//    // 构造b向量和A矩阵
//    // b_k = sum_i w_i * A_i * (sin(pi*k*F_{2i+1}) - sin(pi*k*F_{2i})) / (pi*k)
//    // A_jk = sum_i w_i * (cos(pi*k*(F_{2i+1} - F_{2i})) - cos(pi*k*(F_{2i+1} + F_{2i}))) / (pi^2 * k^2)
//
//    std::vector<float> b_vec(M + 1, 0.0f);
//    af::array A_mat(M + 1, M + 1, 0.0f);
//
//    const float pi = 3.14159265358979323846f;
//
//    for (int k = 0; k <= M; ++k) {
//        float sum_b = 0.0f;
//        for (int band = 0; band < nBands; ++band) {
//            float w = weights[band];
//            float F1 = F[2 * band];
//            float F2 = F[2 * band + 1];
//            float A1 = A[2 * band];
//            float A2 = A[2 * band + 1];
//            float deltaF = F2 - F1;
//
//            if (k == 0) {
//                sum_b += w * (A2 * F2 - A1 * F1);
//            } else {
//                sum_b += w * (A2 * sin(pi * k * F2) - A1 * sin(pi * k * F1)) / (pi * k);
//            }
//        }
//        b_vec[k] = 2.0f * sum_b;
//    }
//
//    for (int r = 0; r <= M; ++r) {
//        for (int c = 0; c <= M; ++c) {
//            float sum_A = 0.0f;
//            for (int band = 0; band < nBands; ++band) {
//                float w = weights[band];
//                float F1 = F[2 * band];
//                float F2 = F[2 * band + 1];
//                float deltaF = F2 - F1;
//
//                if (r == 0 && c == 0) {
//                    sum_A += w * deltaF;
//                } else if (r == 0) {
//                    sum_A += w * (sin(pi * c * F2) - sin(pi * c * F1)) / (pi * c);
//                } else if (c == 0) {
//                    sum_A += w * (sin(pi * r * F2) - sin(pi * r * F1)) / (pi * r);
//                } else {
//                    sum_A += w * (cos(pi * (r - c) * F2) - cos(pi * (r - c) * F1) - cos(pi * (r + c) * F2) + cos(pi * (r + c) * F1)) / (pi * pi * r * c);
//                }
//            }
//            A_mat(r, c) = 2.0f * sum_A;
//        }
//    }
//
//    // 求解线性方程 A_mat * x = b_vec
//    af::array b_af(M + 1, 1, &b_vec[0]);
//    af::array x = solve(A_mat, b_af);
//
//    // 构造对称滤波器系数 h
//    std::vector<float> h(N + 1, 0.0f);
//    for (int i = 0; i <= M; ++i) {
//        h[M + i] = x(i).scalar<float>();
//        h[M - i] = h[M + i];
//    }
//
//    return af::array(N + 1, 1, &h[0]);
//}

/////凯赛尔窗函数
//// 零阶修正贝塞尔函数I0的近似实现
//af::array besselI0(const af::array& x) {
//    // I0(x) ≈ sum_{k=0}^∞ [ (x/2)^{2k} / (k!)^2 ]
//    // 这里取前10项，足够精确
//    af::array result = constant(1, x.dims());
//    af::array x2 = (x / 2) * (x / 2);
//    af::array term = constant(1, x.dims());
//    for (int k = 1; k <= 10; ++k) {
//        term = term * x2 / (k * k);
//        result += term;
//    }
//    return result;
//}
//
//// 凯赛尔窗生成函数
//af::array kaiserWindow(int N, float beta) {
//    if (N <= 1) return constant(1.0f, dim4(N));
//    int M = N - 1;
//    float alpha = M / 2.0f;
//
//    // 生成序列 n = 0,1,...,N-1
//    af::array n = seq(N);
//
//    // 归一化距离 r = (n - alpha) / alpha
//    af::array r = (n - alpha) / alpha;
//
//    // 计算窗函数值
//    af::array arg = beta * sqrt(1 - r * r);
//    af::array w = besselI0(arg) / besselI0(constant(beta, 1));
//
//    return w;
//}

#include <arrayfire.h>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <cstdint>  // for uint32_t

#ifdef max
#undef max
#endif


using namespace af;

const float PI = 3.14159265358979323846f;

// 自定义 sinc 函数，避免除零
array sinc(const array& x) {
    array pix = PI * x;
    array result = sin(pix) / (pix + 1e-12f);
    result(x == 0) = 1.0f;
    return result;
}

float besselI0_approx(float x) {
    float ax = std::abs(x);
    float y, result;
    if (ax < 3.75f) {
        y = (x / 3.75f) * (x / 3.75f);
        result = 1.0f + y * (3.5156229f + y * (3.0899424f + y * (1.2067492f + y * (0.2659732f + y * (0.0360768f + y * 0.0045813f)))));
    } else {
        y = 3.75f / ax;
        result = (std::exp(ax) / std::sqrt(ax)) * (0.39894228f + y * (0.01328592f + y * (0.00225319f + y * (-0.00157565f + y * (0.00916281f + y * (-0.02057706f + y * (0.02635537f + y * (-0.01647633f + y * 0.00392377f))))))));
    }
    return result;
}



array kaiser_window(int len, float beta = 8.6f) {
    array n = iota(dim4(len));
    n -= (len - 1) / 2.0f;
    array ratio = 2.0f * n / (len - 1);
    array w(len);

    float denom = besselI0_approx(beta);
    for (int i = 0; i < len; ++i) {
        float val = beta * std::sqrt(1.0f - ratio(i).scalar<float>() * ratio(i).scalar<float>());
        w(i) = besselI0_approx(val) / denom;
    }
    return w;
}



// 设计低通滤波器
array design_filter(int filter_len, float cutoff, int p, float beta = 8.6f) {
    array n = iota(dim4(filter_len)) - (filter_len - 1) / 2.0f;
    array h = 2 * cutoff * sinc(2 * cutoff * n);
    array w = kaiser_window(filter_len, beta);
    h *= w;
    // 关键修正: 增益乘以p补偿插零带来的幅度衰减
    return h * p / sum<float>(h);
}

// 零插入上采样
array zero_insert(const array& x, int p) {
    int len = x.dims(0);
    int new_len = len * p;
    array y = constant(0, new_len);
    array idx = iota(dim4(len)) * p;
    y(idx) = x;
    return y;
}

array resample(const array& x, int p, int q) {
    int len = x.dims(0);
    int filter_len = 10 * std::max(p, q) + 1;
    float cutoff = 1.0f / (2.0f * std::max(p, q));

    array h = design_filter(filter_len, cutoff, p);  // 传入p参数

    array up = zero_insert(x, p);
    array filtered = convolve1(up, h, AF_CONV_EXPAND);

    int delay = (filter_len - 1) / 2;
    filtered = filtered(seq(delay, delay + up.dims(0) - 1));

    // 关键修正1：正确计算输出长度
    int L = static_cast<int>(std::ceil(len * p / static_cast<float>(q)));

    // 关键修正2：正确生成索引
    array idx = (iota(dim4(L)) * q).as(u32);

    // 边界检查
    unsigned int max_idx = max(idx).scalar<unsigned int>();
    if (max_idx >= filtered.dims(0)) {
        // 自动调整最后几个索引避免越界
        idx = idx(idx < filtered.dims(0));
    }

    return filtered(idx);
}
